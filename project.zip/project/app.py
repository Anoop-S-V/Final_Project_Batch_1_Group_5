import numpy as np
from flask import Flask, render_template, request
import pickle

# model loading
model = pickle.load(open('flask_model1.pkl',"rb"))
app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')


@app.route('/predict', methods=['POST'])
def predict():
    age = float(request.form['Age'])
    typeofcontact = float(request.form['TypeofContact'])
    citytier = float(request.form['CityTier'])
    durationofpitch = float(request.form['DurationOfPitch'])
    gender = float(request.form['Gender'])
    productpitched = float(request.form['ProductPitched'])
    maritalstatus = float(request.form['MaritalStatus'])
    numberoftrips = float(request.form['NumberOfTrips'])
    designation = float(request.form['Designation'])
    arr= np.array([[age, typeofcontact, citytier, durationofpitch, gender, productpitched, maritalstatus, numberoftrips, designation]])
    pred = model.predict(arr)
    if (pred==0):
        result='NO'
    elif (pred==1):
        result='YES'
    return render_template('index.html', prediction_text='Will the client accept the package? - {}'.format(result))

if __name__ == "__main__":
    app.run()
